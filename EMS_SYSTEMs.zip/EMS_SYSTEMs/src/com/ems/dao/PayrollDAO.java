package com.ems.dao;

import com.ems.database.DBConnection;
import java.sql.*;

public class PayrollDAO {

    public void addPayroll(String employee_name, double salary, Date pay_date) {
        try {
            Connection conn = DBConnection.getConnection();

            String query =
                "INSERT INTO payroll (employee_name, salary, pay_date) VALUES (?, ?, ?)";

            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, employee_name);
            stmt.setDouble(2, salary);
            stmt.setDate(3, pay_date);

            stmt.executeUpdate();

            System.out.println("Payroll Added.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ResultSet getPayrolls() {
        ResultSet rs = null;

        try {
            Connection conn = DBConnection.getConnection();

            String query = "SELECT * FROM payroll";

            PreparedStatement stmt = conn.prepareStatement(query);

            rs = stmt.executeQuery(); // FIXED

        } catch (Exception e) {
            e.printStackTrace();
        }

        return rs;
    }

    public void updatePayroll(int payroll_id, String employee_name, double salary, Date pay_date) {

        try {
            Connection conn = DBConnection.getConnection();

            String query =
                "UPDATE payroll SET employee_name = ?, salary = ?, pay_date = ? WHERE payroll_id = ?";

            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, employee_name);
            stmt.setDouble(2, salary);
            stmt.setDate(3, pay_date);
            stmt.setInt(4, payroll_id);

            stmt.executeUpdate();

            System.out.println("Payroll Updated");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deletePayroll(int payroll_id) {

        try {
            Connection conn = DBConnection.getConnection();

            String query = "DELETE FROM payroll WHERE payroll_id = ?";

            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, payroll_id);

            stmt.executeUpdate();

            System.out.println("Payroll Deleted.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}