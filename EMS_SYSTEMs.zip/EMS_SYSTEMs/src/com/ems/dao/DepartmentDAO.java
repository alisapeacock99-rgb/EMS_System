
package com.ems.dao;

import com.ems.database.DBConnection;
import java.sql.*;

public class DepartmentDAO { //This class manages department database operations.
    
    //CREATE method - This method adds a new department into the database.
    public void addDepartment(String department_name){
        
        try{
            Connection conn = DBConnection.getConnection();
            
            //Insert a new row into the departments table.
            String query = 
                "INSERT INTO departments"
                + "(department_name)"
                + "VALUES (?)";
            
            PreparedStatement stmt = conn.prepareStatement(query);//Prepare this SQL query so I can safely send data to the database.            
            stmt.setString(1, department_name);
            
            stmt.executeUpdate(); //Executes the INSERT statement.
            
            System.out.println("Department Added");
                   
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    
    //READ method - This method retrieves department records from the database.
    //"ResultSet" - Method returns query results, is a table-like object that stores data returned from a SQL query.
    public ResultSet getDepartments(){
        ResultSet rs = null;
        
        try{
            Connection conn = DBConnection.getConnection();
            
            //Retrieve all columns and all rows from the departments table.
            String query = 
                "SELECT * FROM departments";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            
            rs = stmt.executeQuery(); //Runs the SQL query.
            
        } catch (Exception e){
            e.printStackTrace();
        }
        return rs; //Returns the ResultSet containing department records.
    }
    
    //UPDATE method - This method updates an department record in the database.
    public void updateDepartment(int department_id, String department_name){

        try{
            Connection conn = DBConnection.getConnection();            

            String query = 
                "UPDATE departments "
            + "SET department_name = ? "
            + "WHERE department_id = ?";

            PreparedStatement stmt = conn.prepareStatement(query);           
            stmt.setString(1, department_name);
            stmt.setInt(2, department_id);

            stmt.executeUpdate();

            System.out.println("Department Updated");

        } catch (Exception e){
            e.printStackTrace();
        }
    }
    
    //DELETE method - This method deletes an department record from the database.
    public void deleteDepartment(int department_id){
        
        try{
            Connection conn = DBConnection.getConnection();
            
            //Delete a row from departments table.
            String query = 
                "DELETE FROM departments "
                + "WHERE department_id = ?";
            
            
            PreparedStatement stmt = conn.prepareStatement(query);     
            stmt.setInt(1, department_id);
            
            stmt.executeUpdate(); //Runs the query, deletes the record.
            
            System.out.println("Department Deleted");
                   
        } catch (Exception e){
            e.printStackTrace();
        }
    }    
    
}
