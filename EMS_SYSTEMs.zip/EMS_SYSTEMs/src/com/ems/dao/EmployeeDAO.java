
package com.ems.dao;

import com.ems.database.DBConnection;
import java.sql.*;

public class EmployeeDAO { //This class manages employee database operations.
    
    //CREATE method - This method adds a new employee into the database.
    public void addEmployee(String full_name, String department, String role, String phone, String email){
        
        try{
            Connection conn = DBConnection.getConnection();
            
            //Insert a new row into the employees table.
            String query = 
                "INSERT INTO employees "
                + "(full_name, department, role, phone, email) "
                + "VALUES (?, ?, ?, ?, ?)";
            
            PreparedStatement stmt = conn.prepareStatement(query);//Prepare this SQL query so I can safely send data to the database.            
            stmt.setString(1, full_name);
            stmt.setString(2, department);
            stmt.setString(3, role);
            stmt.setString(4, phone);
            stmt.setString(5, email);
            
            stmt.executeUpdate(); //Executes the INSERT statement.
            
            System.out.println("Employee Added");
                   
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    
    //READ method - This method retrieves employee records from the database.
    //"ResultSet" - Method returns query results, is a table-like object that stores data returned from a SQL query.
    public ResultSet getEmployees(){
        ResultSet rs = null; //Ensures the variable exists before the try block
        
        try{
            Connection conn = DBConnection.getConnection();
            
            //Retrieve all columns and all rows from the employees table.
            String query = 
                "SELECT * FROM employees";
            
            PreparedStatement stmt = conn.prepareStatement(query);
            
            rs = stmt.executeQuery(); //Runs the SQL query.
            
        } catch (Exception e){
            e.printStackTrace();
        }
        return rs; //Returns the ResultSet containing employee records.
    }
    
    //UPDATE method - This method updates an employee’s record in the database.
    public void updateEmployee(int id, String full_name, String department, String role, String phone, String email){
        
        try{
            Connection conn = DBConnection.getConnection();            
            
            //Update a row in employees table.
            String query = 
                "UPDATE employees "
                + "SET full_name = ?,"
                + "department = ?,"
                + "role = ?,"
                + "phone = ?,"
                + "email = ? "
                + "WHERE id = ?";
            
            
            PreparedStatement stmt = conn.prepareStatement(query);           
            stmt.setString(1, full_name);
            stmt.setString(2, department);
            stmt.setString(3, role);
            stmt.setString(4, phone);
            stmt.setString(5, email);
            stmt.setInt(6, id);
            
            stmt.executeUpdate(); //Runs the query, updating the employee record.
            
            System.out.println("Employee Update");
                   
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    
    //DELETE method - This method deletes an employee’s record from the database.
    public void deleteEmployee(int id){
        
        try{
            Connection conn = DBConnection.getConnection();
            
            //Delete a row from employees table.
            String query = 
                "DELETE FROM employees "
                + "WHERE id = ?";
            
            
            PreparedStatement stmt = conn.prepareStatement(query);     
            stmt.setInt(1, id);
            
            stmt.executeUpdate(); //Runs the query, deletes the record.
            
            System.out.println("Employee Deleted");
                   
        } catch (Exception e){
            e.printStackTrace();
        }
    }    
    
}
