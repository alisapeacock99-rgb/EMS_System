
package com.ems.gui;

import com.ems.dao.PayrollDAO;
import java.sql.Date;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class PayRollFrom extends javax.swing.JFrame {
    
    PayrollDAO dao = new PayrollDAO();
    DefaultTableModel model;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PayRollFrom.class.getName());

    public PayRollFrom() {
        initComponents();
        setLocationRelativeTo(null);

        model = (DefaultTableModel) payrollsTable.getModel();
        txtpay_id.setEnabled(false);
        
        txtpay_date.setText("YYYY-MM-DD");        
        txtpay_date.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                if (txtpay_date.getText().equals("YYYY-MM-DD")) {
                    txtpay_date.setText("");
                }
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                if (txtpay_date.getText().trim().isEmpty()) {
                    txtpay_date.setText("YYYY-MM-DD");
                }
            }
        });

        loadPayrolls();

        payrollsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                fillFieldsFromTable();
            }
        });
    }
    
    private void loadPayrolls() {
        try {
            model.setRowCount(0);

            ResultSet rs = dao.getPayrolls();

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("payroll_id"),
                    rs.getString("employee_name"),
                    rs.getDouble("salary"),
                    rs.getDate("pay_date")
                });
            }

            rs.close();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading payrolls");
        }
    }
    
    private void clearFields() {
        txtpay_id.setText("");
        txtemp_name.setText("");
        txtsalary.setText(" ");
        txtpay_date.setText(" ");
        payrollsTable.clearSelection();
    }
    
    private void fillFieldsFromTable() {
        int row = payrollsTable.getSelectedRow();

        if (row != -1) {
            txtpay_id.setText(model.getValueAt(row, 0).toString());
            txtemp_name.setText(model.getValueAt(row, 1).toString());
            txtsalary.setText(model.getValueAt(row, 2).toString());
            txtpay_date.setText(model.getValueAt(row, 3).toString());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lblemp_name = new javax.swing.JLabel();
        lblsalary = new javax.swing.JLabel();
        lblpay_date = new javax.swing.JLabel();
        txtemp_name = new javax.swing.JTextField();
        txtsalary = new javax.swing.JTextField();
        txtpay_date = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        payrollsTable = new javax.swing.JTable();
        btnAdd = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        lblpayrollID = new javax.swing.JLabel();
        txtpay_id = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitle.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("Employee Management System");

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        lblemp_name.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 15)); // NOI18N
        lblemp_name.setText("Employee Name:");
        lblemp_name.setPreferredSize(new java.awt.Dimension(100, 25));

        lblsalary.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 15)); // NOI18N
        lblsalary.setText("Salary:");
        lblsalary.setPreferredSize(new java.awt.Dimension(100, 25));

        lblpay_date.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 15)); // NOI18N
        lblpay_date.setText("Pay Date:");
        lblpay_date.setPreferredSize(new java.awt.Dimension(100, 25));

        txtemp_name.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        txtemp_name.setPreferredSize(new java.awt.Dimension(180, 25));

        txtsalary.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        txtsalary.setPreferredSize(new java.awt.Dimension(180, 25));

        txtpay_date.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        txtpay_date.setPreferredSize(new java.awt.Dimension(180, 25));
        txtpay_date.addActionListener(this::txtpay_dateActionPerformed);

        payrollsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Payroll ID", "Employee Name", "Salary", "Pay Date"
            }
        ));
        jScrollPane1.setViewportView(payrollsTable);

        btnAdd.setFont(new java.awt.Font("Yu Gothic UI", 1, 12)); // NOI18N
        btnAdd.setText("ADD");
        btnAdd.setPreferredSize(new java.awt.Dimension(100, 25));
        btnAdd.addActionListener(this::btnAddActionPerformed);

        btnUpdate.setFont(new java.awt.Font("Yu Gothic UI", 1, 12)); // NOI18N
        btnUpdate.setText("UPDATE");
        btnUpdate.setPreferredSize(new java.awt.Dimension(100, 25));
        btnUpdate.addActionListener(this::btnUpdateActionPerformed);

        btnDelete.setFont(new java.awt.Font("Yu Gothic UI", 1, 12)); // NOI18N
        btnDelete.setText("DELETE");
        btnDelete.setPreferredSize(new java.awt.Dimension(100, 25));
        btnDelete.addActionListener(this::btnDeleteActionPerformed);

        btnClear.setFont(new java.awt.Font("Yu Gothic UI", 1, 12)); // NOI18N
        btnClear.setText("CLEAR");
        btnClear.setPreferredSize(new java.awt.Dimension(100, 25));
        btnClear.addActionListener(this::btnClearActionPerformed);

        btnPrevious.setFont(new java.awt.Font("Yu Gothic UI", 1, 12)); // NOI18N
        btnPrevious.setText("PREVIOUS");
        btnPrevious.addActionListener(this::btnPreviousActionPerformed);

        lblpayrollID.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 15)); // NOI18N
        lblpayrollID.setText("Payroll ID:");
        lblpayrollID.setPreferredSize(new java.awt.Dimension(100, 25));

        txtpay_id.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        txtpay_id.setPreferredSize(new java.awt.Dimension(180, 25));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblpay_date, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                        .addComponent(txtpay_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblsalary, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtsalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(lblemp_name, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtemp_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblpayrollID, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtpay_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.PREFERRED_SIZE, 454, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblpayrollID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtpay_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblemp_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtemp_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblsalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtsalary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblpay_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtpay_date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPrevious)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitle, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        // TODO add your handling code here:
        try {
            String name = txtemp_name.getText().trim();
            String salaryText = txtsalary.getText().trim();
            String dateText = txtpay_date.getText().trim();

            if (name.isEmpty() || salaryText.isEmpty() || dateText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required");
                return;
            }

            double salary = Double.parseDouble(salaryText);
            Date payDate = Date.valueOf(dateText);

            dao.addPayroll(name, salary, payDate);

            JOptionPane.showMessageDialog(this, "Payroll Added");

            loadPayrolls();
            clearFields();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Invalid input. Salary must be numeric and date must be YYYY-MM-DD");
        }
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        // TODO add your handling code here:
        if (txtpay_id.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a payroll first");
            return;
        }

        try {
            int id = Integer.parseInt(txtpay_id.getText().trim());
            String name = txtemp_name.getText().trim();
            double salary = Double.parseDouble(txtsalary.getText().trim());
            Date payDate = Date.valueOf(txtpay_date.getText().trim());

            dao.updatePayroll(id, name, salary, payDate);

            JOptionPane.showMessageDialog(this, "Payroll Updated");

            loadPayrolls();
            clearFields();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid input format");
        }
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:
        if (txtpay_id.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a payroll first");
            return;
        }

        try {
            int id = Integer.parseInt(txtpay_id.getText().trim());

            dao.deletePayroll(id);

            JOptionPane.showMessageDialog(this, "Payroll Deleted");

            loadPayrolls();
            clearFields();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid payroll ID");
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        new DashboardForm().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnPreviousActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        // TODO add your handling code here:
        clearFields();
    }//GEN-LAST:event_btnClearActionPerformed

    private void txtpay_dateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtpay_dateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtpay_dateActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new PayRollFrom().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lblemp_name;
    private javax.swing.JLabel lblpay_date;
    private javax.swing.JLabel lblpayrollID;
    private javax.swing.JLabel lblsalary;
    private javax.swing.JTable payrollsTable;
    private javax.swing.JTextField txtemp_name;
    private javax.swing.JTextField txtpay_date;
    private javax.swing.JTextField txtpay_id;
    private javax.swing.JTextField txtsalary;
    // End of variables declaration//GEN-END:variables
}
