
package com.ems.gui;

import com.ems.dao.EmployeeDAO;
import java.sql.ResultSet; //Used to store records returned from the database.
import javax.swing.JOptionPane; //Used to show popup messages.
import javax.swing.table.DefaultTableModel; //Used to manage rows and columns in JTable.
import java.io.*;

public class EmployeeForm extends javax.swing.JFrame {
    
    EmployeeDAO dao = new EmployeeDAO();
    DefaultTableModel model; //Stores the table model used by employeeTable.
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(EmployeeForm.class.getName());

    public EmployeeForm() {
        initComponents();

        setLocationRelativeTo(null); //Centers the form on the screen.
        model = (DefaultTableModel) employeeTable.getModel(); //Gets the table model from employeeTable.

        
        txtId.setEnabled(false); // ID is auto-generated - Makes Employee ID field read-only.
        loadEmployees(); //Loads employees from the database into the table.
        //Adds a listener to detect row selection.
        employeeTable.getSelectionModel().addListSelectionListener(e -> { 
            if (!e.getValueIsAdjusting()) { //Prevents duplicate events.
            fillFieldsFromTable(); //Fills text fields with selected row data.
        }
});
}
    //Loads employee data from database into table.
    private void loadEmployees(){
        try {
            model.setRowCount(0); //Clears existing rows from table.

            ResultSet rs = dao.getEmployees(); //Fetches employee records from database.

            //Loop Through Database Records
            while (rs.next()) {
                model.addRow(new Object[]{ //Adds a new row to the table.
                        rs.getInt("id"),
                        rs.getString("full_name"),
                        rs.getString("department"), // FIXED
                        rs.getString("role"),
                        rs.getString("phone"),
                        rs.getString("email")
                });
            }

            rs.close(); //Closes the ResultSet.

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    //Clears all input fields.
    public void clearFields(){
        txtId.setText("");
        txtName.setText("");
        txtDepartment.setText("");
        txtRole.setText("");
        txtPhone.setText("");
        txtEmail.setText("");

        employeeTable.clearSelection(); //Removes selected row from table.
    }
    
    //Fills text fields using selected table row.
    private void fillFieldsFromTable() {
        int row = employeeTable.getSelectedRow(); //Gets selected row number.

        //Checks if a row is selected.
        if (row != -1) {
            txtId.setText(model.getValueAt(row, 0).toString());
            txtName.setText(model.getValueAt(row, 1).toString());
            txtDepartment.setText(model.getValueAt(row, 2).toString());
            txtRole.setText(model.getValueAt(row, 3).toString());
            txtPhone.setText(model.getValueAt(row, 4).toString());
            txtEmail.setText(model.getValueAt(row, 5).toString());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel6 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        lblTitle = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lblfull_name = new javax.swing.JLabel();
        lbldept = new javax.swing.JLabel();
        lblrole = new javax.swing.JLabel();
        lblphone = new javax.swing.JLabel();
        lblemail = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        txtDepartment = new javax.swing.JTextField();
        txtRole = new javax.swing.JTextField();
        txtPhone = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        employeeTable = new javax.swing.JTable();
        btnAdd = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        btnPrevious = new javax.swing.JButton();
        lblfull_name1 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();

        jLabel6.setFont(new java.awt.Font("Yu Gothic Medium", 0, 15)); // NOI18N
        jLabel6.setText("Phone:");
        jLabel6.setPreferredSize(new java.awt.Dimension(100, 25));

        jButton4.setText("DELETE");
        jButton4.setPreferredSize(new java.awt.Dimension(100, 25));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitle.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("Employee Management System");

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        lblfull_name.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 15)); // NOI18N
        lblfull_name.setText("Full Name:");
        lblfull_name.setPreferredSize(new java.awt.Dimension(100, 25));

        lbldept.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 15)); // NOI18N
        lbldept.setText("Department:");
        lbldept.setPreferredSize(new java.awt.Dimension(100, 25));

        lblrole.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 15)); // NOI18N
        lblrole.setText("Role:");
        lblrole.setPreferredSize(new java.awt.Dimension(100, 25));

        lblphone.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 15)); // NOI18N
        lblphone.setText("Phone:");
        lblphone.setPreferredSize(new java.awt.Dimension(100, 25));

        lblemail.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 15)); // NOI18N
        lblemail.setText("Email:");
        lblemail.setPreferredSize(new java.awt.Dimension(100, 25));

        txtName.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        txtName.setPreferredSize(new java.awt.Dimension(200, 25));

        txtDepartment.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        txtDepartment.setPreferredSize(new java.awt.Dimension(200, 25));

        txtRole.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        txtRole.setPreferredSize(new java.awt.Dimension(200, 25));

        txtPhone.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        txtPhone.setPreferredSize(new java.awt.Dimension(200, 25));

        txtEmail.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        txtEmail.setPreferredSize(new java.awt.Dimension(200, 25));

        employeeTable.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        employeeTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Employee ID", "Full Name", "Department", "Role", "Phone", "Email"
            }
        ));
        jScrollPane1.setViewportView(employeeTable);

        btnAdd.setFont(new java.awt.Font("Yu Gothic UI", 1, 12)); // NOI18N
        btnAdd.setText("ADD");
        btnAdd.setPreferredSize(new java.awt.Dimension(100, 25));
        btnAdd.addActionListener(this::btnAddActionPerformed);

        btnUpdate.setFont(new java.awt.Font("Yu Gothic UI", 1, 12)); // NOI18N
        btnUpdate.setText("UPDATE");
        btnUpdate.setPreferredSize(new java.awt.Dimension(100, 25));
        btnUpdate.addActionListener(this::btnUpdateActionPerformed);

        btnDelete.setFont(new java.awt.Font("Yu Gothic UI", 1, 12)); // NOI18N
        btnDelete.setText("DELETE");
        btnDelete.setPreferredSize(new java.awt.Dimension(100, 25));
        btnDelete.addActionListener(this::btnDeleteActionPerformed);

        btnClear.setFont(new java.awt.Font("Yu Gothic UI", 1, 12)); // NOI18N
        btnClear.setText("CLEAR");
        btnClear.setPreferredSize(new java.awt.Dimension(100, 25));
        btnClear.addActionListener(this::btnClearActionPerformed);

        btnPrevious.setFont(new java.awt.Font("Yu Gothic UI", 1, 12)); // NOI18N
        btnPrevious.setText("PREVIOUS");
        btnPrevious.addActionListener(this::btnPreviousActionPerformed);

        lblfull_name1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 15)); // NOI18N
        lblfull_name1.setText("Employee ID:");
        lblfull_name1.setPreferredSize(new java.awt.Dimension(100, 25));

        txtId.setEditable(false);
        txtId.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        txtId.setAlignmentX(0.0F);
        txtId.setPreferredSize(new java.awt.Dimension(200, 25));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblphone, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPhone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblrole, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtRole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lbldept, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblfull_name, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblemail, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblfull_name1, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnPrevious, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblfull_name1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblfull_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lbldept, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtDepartment, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblrole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtRole, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblphone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPhone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblemail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAdd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnPrevious)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addComponent(lblTitle, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(lblTitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPreviousActionPerformed
        // TODO add your handling code here:
        new DashboardForm().setVisible(true); //Opens dashboard form.
        this.dispose(); //Closes current form.
    }//GEN-LAST:event_btnPreviousActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        // TODO add your handling code here:
        
        if(txtName.getText().isEmpty() || txtDepartment.getText().isEmpty() || txtRole.getText().isEmpty() || txtPhone.getText().isEmpty() || txtEmail.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, 
                    "Please enter all fields",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);            
        } else {
            //Calls database method to add employee.
            dao.addEmployee(
                txtName.getText(),
                txtDepartment.getText(), 
                txtRole.getText(),
                txtPhone.getText(),
                txtEmail.getText()
            );
            
            JOptionPane.showMessageDialog(this, "Employee Added");
            
            loadEmployees();
            clearFields();
        }
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        // TODO add your handling code here:
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select an employee first");
            
        } else {
            dao.updateEmployee(
                    Integer.parseInt(txtId.getText()),
                    txtName.getText(),
                    txtDepartment.getText(), 
                    txtRole.getText(),
                    txtPhone.getText(),
                    txtEmail.getText()
            );

            JOptionPane.showMessageDialog(this, "Employee Updated");
            loadEmployees();
            clearFields();
        }

        
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:
         if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select an employee first");
            
        } else {
             dao.deleteEmployee(Integer.parseInt(txtId.getText()));

            JOptionPane.showMessageDialog(this, "Employee Deleted");
            loadEmployees();
            clearFields();
        }

        
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        // TODO add your handling code here:
        clearFields();
    }//GEN-LAST:event_btnClearActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new EmployeeForm().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnPrevious;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JTable employeeTable;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JLabel lbldept;
    private javax.swing.JLabel lblemail;
    private javax.swing.JLabel lblfull_name;
    private javax.swing.JLabel lblfull_name1;
    private javax.swing.JLabel lblphone;
    private javax.swing.JLabel lblrole;
    private javax.swing.JTextField txtDepartment;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPhone;
    private javax.swing.JTextField txtRole;
    // End of variables declaration//GEN-END:variables
}
