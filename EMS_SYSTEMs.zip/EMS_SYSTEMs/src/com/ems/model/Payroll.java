
package com.ems.model;
import java.util.*;

public class Payroll {
    //Fields
    private int payId;
    private String empName;
    private double salary;
    private Date payDate;
    
    //Constructor
    public Payroll(int payId, String empName, double salary, Date payDate){
        this.payId = payId;
        this.empName = empName;
        this.salary = salary;
        this.payDate = payDate;
    }
    
    //Getter methods:
    public int getPayId(){
        return payId;
    }
    
    public String getEmpName(){
        return empName;
    }
    
    public double getSalary(){
        return salary;
    }
    
    public Date getPayDate(){
        return payDate;
    }
    
    //Setter methods:
    public void setPayId(int payId){
        this.payId = payId;
    }
    
    public void setEmpName(String empName){
        this.empName = empName;
    }
    
    public void setSalary(double salary){
        this.salary = salary;
    }
    
    public void setPayDate(Date payDate){
        this.payDate = payDate;
    }
    
}
