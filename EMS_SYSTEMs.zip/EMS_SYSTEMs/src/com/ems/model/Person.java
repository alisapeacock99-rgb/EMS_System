
package com.ems.model;

public abstract class Person {
    //Fields - Protected, Fields are accessible within the same package and by subclasses.
    protected String fullName;
    protected String phone;
    protected String email;
    
    //Constructor
    public Person(String fullName, String phone, String email){
        this.fullName = fullName;
        this.phone = phone;
        this.email = email;
    }
    
    //Getter methods - Provide controlled, flexible, and future-proof access to those fields.
    public String getFullName(){
        return fullName;
    }
    
    public String getPhone(){
        return phone;
    }
    
    public String getEmail(){
        return email;
    }
    
    //Abstract Method:
    public abstract void display();
    
}
