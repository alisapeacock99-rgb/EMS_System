
package com.ems.model;

public class Department {
    //Fields
    private int deptId;
    private String deptName;
    
    //Construcator
    public Department(int deptId, String deptName){
        this.deptId = deptId;
        this.deptName = deptName;
    }
    
    //Getter methods:
    public int getDeptId(){
        return deptId;
    }
    
    public String getDeptName(){
        return deptName;
    }
    
    //Setter methods:
    public void setDeptId(int deptId){
        this.deptId = deptId;
    }
    
    public void setDeptName(String deptName){
        this.deptName = deptName;
    }
}
