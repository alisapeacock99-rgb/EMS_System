
package com.ems.model;

public class Employee extends Person {
    //Fields - Private, Fields are accessible only within the same class. 
    private int id;
    private String department;
    private String role;
    
    //Constructor
    public Employee(int id, String department, String role, String fullName, String phone, String email){
        super(fullName, phone, email);
        this.id = id;
        this.department = department;
        this.role = role;
    }
    
    //Getter methods:
    public int getId(){
        return id;
    }
    
    public String getDepartment(){
        return department;
    }
    
    public String getRole(){
        return role;
    }
    
    @Override
    public void display(){
        System.out.println("Employee - " + fullName + "'s Role is: " + role);
    }
    
}
