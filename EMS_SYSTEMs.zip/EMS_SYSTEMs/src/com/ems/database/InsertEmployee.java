package com.ems.database;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class InsertEmployee {

    public static void main(String[] args) {

        try {

            Connection conn =
                DBConnection.getConnection();

            String query =
                "INSERT INTO employees "
                + "(full_name, department, role, phone, email) "
                + "VALUES (?, ?, ?, ?, ?)";

            PreparedStatement stmt =
                conn.prepareStatement(query);

            // Employee 1
            stmt.setString(1, "John Doe");
            stmt.setString(2, "IT");
            stmt.setString(3, "Developer");
            stmt.setString(4, "0123456789");
            stmt.setString(5, "john@email.com");

            stmt.executeUpdate();

            // Employee 2
            stmt.setString(1, "Sarah Smith");
            stmt.setString(2, "HR");
            stmt.setString(3, "Manager");
            stmt.setString(4, "0987654321");
            stmt.setString(5, "sarah@email.com");

            stmt.executeUpdate();

            System.out.println(
                "Employees inserted successfully"
            );

            conn.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}