package com.ems.database;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class DepartmentTest {

    public static void main(String[] args) {

        String[] departments = {"IT", "HR", "Finance", "Marketing"};

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO departments (department_name) VALUES (?)")) {

            if (conn == null) {
                System.out.println("Connection failed");
                return;
            }

            for (String dept : departments) {
                stmt.setString(1, dept);
                stmt.executeUpdate();
                System.out.println(dept + " inserted");
            }

            System.out.println("All departments inserted successfully ");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}