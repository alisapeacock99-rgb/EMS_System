package com.ems.database;

import java.sql.*;

public class DriverTest {

    public static void main(String[] args) {

        System.out.println("Starting test...");

        try {
            Connection conn = DriverManager.getConnection("jdbc:derby:EMSDB;create=true");
            System.out.println("CONNECTED SUCCESSFULLY");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}