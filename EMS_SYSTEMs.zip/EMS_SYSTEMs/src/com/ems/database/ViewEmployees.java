package com.ems.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ViewEmployees {

    public static void main(String[] args) {

        try {

            Connection conn =
                DBConnection.getConnection();

            String query =
                "SELECT * FROM employees";

            PreparedStatement stmt =
                conn.prepareStatement(query);

            ResultSet rs =
                stmt.executeQuery();

            System.out.println(
                "===== EMPLOYEE LIST ====="
            );

            while (rs.next()) {

                System.out.println(
                    rs.getInt("id") + " | "
                    + rs.getString("full_name") + " | "
                    + rs.getString("department") + " | "
                    + rs.getString("role") + " | "
                    + rs.getString("phone") + " | "
                    + rs.getString("email")
                );
            }

            conn.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}