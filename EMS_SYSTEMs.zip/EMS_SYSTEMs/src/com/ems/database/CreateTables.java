package com.ems.database;

import java.sql.Connection;
import java.sql.Statement;

public class CreateTables {

    public static void main(String[] args) {

        try {

            Connection conn = DBConnection.getConnection();

            Statement stmt = conn.createStatement();

            // DROP OLD TABLES 

            try {
                stmt.executeUpdate("DROP TABLE payroll");
            } catch (Exception e) {}

            try {
                stmt.executeUpdate("DROP TABLE employees");
            } catch (Exception e) {}

            try {
                stmt.executeUpdate("DROP TABLE departments");
            } catch (Exception e) {}

            System.out.println("Old tables dropped.");

            // EMPLOYEES TABLE 

            String employeesTable =
                "CREATE TABLE employees ("
                + "id INT PRIMARY KEY "
                + "GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), "
                + "full_name VARCHAR(100), "
                + "department VARCHAR(100), "
                + "role VARCHAR(100), "
                + "phone VARCHAR(20), "
                + "email VARCHAR(100))";

            stmt.executeUpdate(employeesTable);

            System.out.println("Employees table created");

            // DEPARTMENTS TABLE 

            String departmentsTable =
                "CREATE TABLE departments ("
                + "department_id INT PRIMARY KEY "
                + "GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), "
                + "department_name VARCHAR(100))";

            stmt.executeUpdate(departmentsTable);

            System.out.println("Departments table created");

            //PAYROLL TABLE

            String payrollTable =
                "CREATE TABLE payroll ("
                + "payroll_id INT PRIMARY KEY "
                + "GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), "
                + "employee_name VARCHAR(100), "
                + "salary DOUBLE, "
                + "pay_date DATE)";

            stmt.executeUpdate(payrollTable);

            System.out.println("Payroll table created");

            conn.close();

            System.out.println("All tables created successfully");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}