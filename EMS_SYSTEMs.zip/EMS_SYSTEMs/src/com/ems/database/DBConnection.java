package com.ems.database;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    public static Connection getConnection() {
        try {
            return DriverManager.getConnection("jdbc:derby:EMSDB;create=true");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}